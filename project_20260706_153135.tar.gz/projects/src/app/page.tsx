'use client';

import { useState, useEffect } from 'react';
import { trademarkCategories, searchTrademarks } from '@/data/trademark-data';
import { allDetailedCategories } from '@/data/detailed-items';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Search, ChevronRight, Package } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [keyword, setKeyword] = useState('');
  const [searchResults, setSearchResults] = useState<ReturnType<typeof searchTrademarks>>([]);
  const [showResults, setShowResults] = useState(false);

  // 搜索详细商品
  const searchDetailedItems = (keyword: string) => {
    const results: { categoryId: number; categoryName: string; subCode: string; subName: string; items: { code: string; name: string }[] }[] = [];
    
    Object.entries(allDetailedCategories).forEach(([catId, subCategories]) => {
      const category = trademarkCategories.find(c => c.id === parseInt(catId));
      if (!category) return;
      
      subCategories.forEach(subCat => {
        const matchedItems = subCat.items.filter(item =>
          item.name.toLowerCase().includes(keyword.toLowerCase()) ||
          item.code.includes(keyword)
        );
        
        if (matchedItems.length > 0) {
          results.push({
            categoryId: parseInt(catId),
            categoryName: category.title,
            subCode: subCat.code,
            subName: subCat.title,
            items: matchedItems
          });
        }
      });
    });
    
    return results;
  };

  const [detailedResults, setDetailedResults] = useState<ReturnType<typeof searchDetailedItems>>([]);

  const handleSearch = () => {
    if (!keyword.trim()) {
      setShowResults(false);
      setDetailedResults([]);
      return;
    }
    
    // 搜索小类
    const results = searchTrademarks(keyword);
    const filteredResults = selectedCategory && selectedCategory !== 'all'
      ? results.filter(r => r.categoryId === parseInt(selectedCategory))
      : results;
    
    // 搜索详细商品
    const detailedSearchResults = searchDetailedItems(keyword);
    const filteredDetailedResults = selectedCategory && selectedCategory !== 'all'
      ? detailedSearchResults.filter(r => r.categoryId === parseInt(selectedCategory))
      : detailedSearchResults;
    
    setSearchResults(filteredResults);
    setDetailedResults(filteredDetailedResults);
    setShowResults(true);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  // 平滑滚动到指定分类
  const scrollToCategory = (id: number) => {
    const element = document.getElementById(`category-${id}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50 to-white dark:from-gray-900 dark:to-gray-800">
      {/* 顶部横幅 */}
      <div className="bg-gradient-to-r from-red-600 to-red-700 dark:from-red-800 dark:to-red-900 text-white py-4 px-4 shadow-lg">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <Image 
              src="/logo.png" 
              alt="商标分类" 
              width={40} 
              height={40} 
              className="rounded-full"
            />
            <Badge variant="secondary" className="text-red-800 bg-white">商标分类</Badge>
            <span className="text-sm md:text-base">
              尼斯分类商品和服务分类表（尼斯分类第十版2026文本）
            </span>
            <span className="text-xs md:text-sm opacity-90">(2026年1月3日)</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* 搜索区域 */}
        <Card className="mb-6 shadow-lg">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4 items-end">
              <div className="flex-1 w-full">
                <label className="block text-sm font-medium mb-2 text-gray-700 dark:text-gray-300">
                  商品/服务项目搜索
                </label>
                <div className="flex gap-3">
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger className="w-[140px]">
                      <SelectValue placeholder="选择分类" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部分类</SelectItem>
                      {trademarkCategories.map(cat => (
                        <SelectItem key={cat.id} value={cat.id.toString()}>
                          第{cat.id}类
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    type="text"
                    placeholder="请输入商品或服务名称..."
                    value={keyword}
                    onChange={(e) => setKeyword(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="flex-1"
                  />
                  <Button onClick={handleSearch} className="bg-red-600 hover:bg-red-700">
                    <Search className="w-4 h-4 mr-2" />
                    搜索商品
                  </Button>
                </div>
              </div>
            </div>

            {/* 搜索结果 */}
            {showResults && (
              <div className="mt-6 border-t pt-4">
                <h3 className="font-semibold mb-3 text-lg">搜索结果</h3>
                
                {/* 详细商品搜索结果 */}
                {detailedResults.length > 0 && (
                  <div className="mb-6">
                    <h4 className="font-medium text-red-700 dark:text-red-300 mb-3 flex items-center gap-2">
                      <Package className="w-4 h-4" />
                      详细商品匹配 ({detailedResults.reduce((sum, r) => sum + r.items.length, 0)}项)
                    </h4>
                    <ScrollArea className="h-[300px] w-full rounded border p-4 mb-4 bg-red-50 dark:bg-red-900/20">
                      {detailedResults.map(result => (
                        <div key={`${result.categoryId}-${result.subCode}`} className="mb-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Link 
                              href={`/category/${result.categoryId}#${result.subCode}`}
                              className="font-semibold text-red-600 dark:text-red-400 hover:underline"
                            >
                              {result.categoryName} - {result.subCode}
                            </Link>
                            <span className="text-gray-500 text-sm">({result.subName})</span>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                            {result.items.map(item => (
                              <Link 
                                key={item.code} 
                                href={`/category/${result.categoryId}#${result.subCode}`}
                                className="flex items-center gap-2 p-2 rounded hover:bg-white dark:hover:bg-gray-800 transition-colors border border-transparent hover:border-red-200"
                              >
                                <Badge variant="outline" className="text-xs">{item.code}</Badge>
                                <span className="text-sm">{item.name}</span>
                              </Link>
                            ))}
                          </div>
                        </div>
                      ))}
                    </ScrollArea>
                  </div>
                )}
                
                {/* 小类搜索结果 */}
                {searchResults.length === 0 && detailedResults.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">未找到相关结果</p>
                ) : searchResults.length > 0 && (
                  <div>
                    <h4 className="font-medium text-gray-700 dark:text-gray-300 mb-3">
                      小类匹配 ({searchResults.reduce((sum, r) => sum + r.items.length, 0)}项)
                    </h4>
                    <ScrollArea className="h-[300px] w-full rounded border p-4">
                      {searchResults.map(result => (
                        <div key={result.categoryId} className="mb-4">
                          <div className="font-semibold text-red-600 dark:text-red-400 mb-2">
                            {result.categoryName}
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                            {result.items.map(item => (
                              <Link 
                                key={item.code} 
                                href={`/category/${result.categoryId}#${item.code}`}
                                className="flex items-center gap-2 p-2 rounded hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                              >
                                <Badge variant="outline" className="text-xs">{item.code}</Badge>
                                <span className="text-sm">{item.name}</span>
                              </Link>
                            ))}
                          </div>
                        </div>
                      ))}
                    </ScrollArea>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* 分类导航 */}
        <Card className="mb-6 shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">商标分类导航</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-5 sm:grid-cols-9 md:grid-cols-12 lg:grid-cols-15 gap-2">
              {trademarkCategories.map(cat => (
                <Button
                  key={cat.id}
                  variant="outline"
                  size="sm"
                  onClick={() => scrollToCategory(cat.id)}
                  className="text-xs hover:bg-red-50 dark:hover:bg-red-900"
                >
                  第{cat.id}类
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* 分类详情列表 */}
        <div className="space-y-6">
          {trademarkCategories.map(category => (
            <Card key={category.id} id={`category-${category.id}`} className="shadow-lg scroll-mt-20">
              <CardHeader className="bg-gradient-to-r from-red-50 to-white dark:from-gray-800 dark:to-gray-900">
                <CardTitle className="flex items-center gap-2">
                  <Badge className="bg-red-600 text-white">{category.title}</Badge>
                </CardTitle>
                <CardDescription className="text-sm leading-relaxed mt-2">
                  {category.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {category.items.map(item => {
                    const detailedCount = allDetailedCategories[category.id]?.find(d => d.code === item.code)?.items.length || 0;
                    
                    return (
                      <Link
                        key={item.code}
                        href={`/category/${category.id}#${item.code}`}
                        id={item.code}
                        className="flex items-start gap-2 p-3 rounded-lg border hover:border-red-300 hover:shadow-md transition-all group"
                      >
                        <Badge variant="secondary" className="mt-0.5 shrink-0">{item.code}</Badge>
                        <span className="text-sm flex-1 group-hover:text-red-600 dark:group-hover:text-red-400 transition-colors">
                          {item.name}
                        </span>
                        {detailedCount > 0 && (
                          <Badge variant="outline" className="text-xs text-gray-500">
                            {detailedCount}项
                          </Badge>
                        )}
                        <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity text-red-600" />
                      </Link>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* 底部信息 */}
      <div className="bg-gray-100 dark:bg-gray-900 border-t mt-8 py-6">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-gray-600 dark:text-gray-400">
          <p>ABC商标分类查询系统 - 基于2026版尼斯分类</p>
          <p className="mt-2">
            Copyright © 2024 ABC All Right Reserved
          </p>
        </div>
      </div>
    </div>
  );
}
