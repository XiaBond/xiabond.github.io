import type { Metadata } from 'next';
import { Inspector } from 'react-dev-inspector';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: '商标分类查询 | ABC',
    template: '%s | ABC',
  },
  description:
    'ABC商标分类查询系统，提供基于尼斯分类2026版的商标分类查询服务，涵盖45类商标分类的详细商品和服务项目。',
  keywords: [
    'ABC',
    '商标分类',
    '商标查询',
    '尼斯分类',
    '商标注册',
    '商标分类表',
    '商品分类',
    '服务分类',
    '商标分类查询',
  ],
  authors: [{ name: 'ABC Team', url: 'https://abc.com' }],
  generator: 'ABC',
  icons: {
    icon: '/logo.png',
  },
  openGraph: {
    title: 'ABC商标分类查询 | 基于2026版尼斯分类',
    description:
      'ABC商标分类查询系统，提供基于尼斯分类2026版的商标分类查询服务，涵盖45类商标分类的详细商品和服务项目。',
    url: 'https://abc.com',
    siteName: 'ABC商标分类查询',
    locale: 'zh_CN',
    type: 'website',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const isDev = process.env.COZE_PROJECT_ENV === 'DEV';

  return (
    <html lang="zh-CN">
      <body className={`antialiased`}>
        {isDev && <Inspector />}
        {children}
      </body>
    </html>
  );
}
