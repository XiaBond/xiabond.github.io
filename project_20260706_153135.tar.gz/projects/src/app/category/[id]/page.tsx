'use client';

import { useParams } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { trademarkCategories } from '@/data/trademark-data';
import { allDetailedCategories, SubCategoryDetail } from '@/data/detailed-items';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowLeft, ChevronRight, Home, ChevronDown, ChevronUp, ShoppingCart, Copy, X, Check, Trash2 } from 'lucide-react';
import { useEffect, useState, useCallback } from 'react';

interface SelectedItem {
  code: string;
  name: string;
  subCode: string;
  subName: string;
}

export default function CategoryPage() {
  const params = useParams();
  const categoryId = parseInt(params.id as string);
  const category = trademarkCategories.find(c => c.id === categoryId);
  const detailedData = allDetailedCategories[categoryId];
  
  const [expandedSubCategories, setExpandedSubCategories] = useState<Set<string>>(new Set());
  const [selectedItems, setSelectedItems] = useState<SelectedItem[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);

  // 从localStorage加载已选择的商品
  useEffect(() => {
    const saved = localStorage.getItem(`selectedItems_${categoryId}`);
    if (saved) {
      try {
        setSelectedItems(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load selected items');
      }
    }
  }, [categoryId]);

  // 保存到localStorage
  useEffect(() => {
    localStorage.setItem(`selectedItems_${categoryId}`, JSON.stringify(selectedItems));
  }, [selectedItems, categoryId]);

  useEffect(() => {
    // 检查是否有锚点，如果有则滚动到该位置
    if (window.location.hash) {
      const element = document.getElementById(window.location.hash.substring(1));
      if (element) {
        setTimeout(() => {
          element.scrollIntoView({ behavior: 'smooth', block: 'center' });
          element.classList.add('ring-2', 'ring-red-500', 'ring-offset-2');
        }, 100);
      }
    }
  }, []);

  const toggleSubCategory = (code: string) => {
    const newExpanded = new Set(expandedSubCategories);
    if (newExpanded.has(code)) {
      newExpanded.delete(code);
    } else {
      newExpanded.add(code);
    }
    setExpandedSubCategories(newExpanded);
  };

  const toggleItem = useCallback((item: { code: string; name: string }, subCode: string, subName: string) => {
    setSelectedItems(prev => {
      const exists = prev.find(i => i.code === item.code);
      if (exists) {
        return prev.filter(i => i.code !== item.code);
      } else {
        return [...prev, { ...item, subCode, subName }];
      }
    });
  }, []);

  const isSelected = useCallback((code: string) => {
    return selectedItems.some(i => i.code === code);
  }, [selectedItems]);

  const removeItem = useCallback((code: string) => {
    setSelectedItems(prev => prev.filter(i => i.code !== code));
  }, []);

  const clearAll = useCallback(() => {
    setSelectedItems([]);
  }, []);

  const copyToClipboard = useCallback(async () => {
    if (selectedItems.length === 0) return;
    
    const text = selectedItems.map(item => `${item.name}${item.code}`).join('；');
    
    try {
      await navigator.clipboard.writeText(text);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  }, [selectedItems]);

  if (!category) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <Card className="max-w-md">
          <CardContent className="pt-6">
            <div className="text-center">
              <p className="text-lg font-semibold mb-2">分类不存在</p>
              <p className="text-gray-500 dark:text-gray-400 mb-4">未找到该商标分类</p>
              <Link href="/">
                <Button className="bg-red-600 hover:bg-red-700">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  返回首页
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50 to-white dark:from-gray-900 dark:to-gray-800 pb-24">
      {/* 顶部横幅 */}
      <div className="bg-gradient-to-r from-red-600 to-red-700 dark:from-red-800 dark:to-red-900 text-white py-4 px-4 shadow-lg">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-3">
            <Image 
              src="/logo.png" 
              alt="商标分类" 
              width={40} 
              height={40} 
              className="rounded-full"
            />
            <Badge variant="secondary" className="text-red-800 bg-white">商标分类</Badge>
            <span className="text-sm md:text-base">
              尼斯分类商品和服务分类表（尼斯分类第十版2026文本）
            </span>
            <span className="text-xs md:text-sm opacity-90">(2026年1月3日)</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* 面包屑导航 */}
        <div className="flex items-center gap-2 mb-6 text-sm">
          <Link href="/" className="flex items-center gap-1 text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300">
            <Home className="w-4 h-4" />
            首页
          </Link>
          <ChevronRight className="w-4 h-4 text-gray-400" />
          <span className="text-gray-600 dark:text-gray-400">{category.title}</span>
        </div>

        {/* 分类详情 */}
        <Card className="shadow-lg mb-6">
          <CardHeader className="bg-gradient-to-r from-red-50 to-white dark:from-gray-800 dark:to-gray-900">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-3">
                <Badge className="bg-red-600 text-white text-lg px-4 py-2">{category.title}</Badge>
              </CardTitle>
              <Link href="/">
                <Button variant="outline" className="hover:bg-red-50 hover:text-red-600 hover:border-red-300">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  返回首页
                </Button>
              </Link>
            </div>
            <CardDescription className="text-base leading-relaxed mt-4 p-4 bg-white dark:bg-gray-900 rounded-lg">
              {category.description}
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            {/* 小类列表 */}
            <div className="space-y-4">
              {category.items.map(item => {
                const isExpanded = expandedSubCategories.has(item.code);
                const detailedItems = detailedData?.find(d => d.code === item.code)?.items || [];
                
                return (
                  <div key={item.code} id={item.code} className="border rounded-lg overflow-hidden">
                    {/* 小类标题 */}
                    <div
                      className={`flex items-center justify-between p-4 cursor-pointer transition-colors ${
                        isExpanded ? 'bg-red-50 dark:bg-red-900/30' : 'bg-white dark:bg-gray-900 hover:bg-gray-50 dark:hover:bg-gray-800'
                      }`}
                      onClick={() => toggleSubCategory(item.code)}
                    >
                      <div className="flex items-center gap-3">
                        <Badge variant="secondary" className="text-base px-3 py-1">{item.code}</Badge>
                        <span className="font-medium">{item.name}</span>
                        {detailedItems.length > 0 && (
                          <Badge variant="outline" className="text-xs">
                            {detailedItems.length}项商品
                          </Badge>
                        )}
                      </div>
                      {detailedItems.length > 0 && (
                        isExpanded ? <ChevronUp className="w-5 h-5 text-gray-600" /> : <ChevronDown className="w-5 h-5 text-gray-600" />
                      )}
                    </div>
                    
                    {/* 详细商品列表 */}
                    {isExpanded && detailedItems.length > 0 && (
                      <div className="border-t bg-white dark:bg-gray-900 p-4">
                        <div className="mb-3 text-sm text-gray-600 dark:text-gray-400 font-medium">
                          点击商品可添加到选择列表（共 {detailedItems.length} 项）
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                          {detailedItems.map(detailItem => {
                            const selected = isSelected(detailItem.code);
                            return (
                              <div
                                key={detailItem.code}
                                onClick={() => toggleItem(detailItem, item.code, item.name)}
                                className={`flex items-start gap-2 p-2 rounded border transition-all cursor-pointer ${
                                  selected 
                                    ? 'border-red-500 bg-red-50 dark:bg-red-900/30 ring-1 ring-red-500' 
                                    : 'hover:border-red-300 hover:bg-red-50/50 dark:hover:bg-red-900/20'
                                }`}
                              >
                                {selected && (
                                  <Check className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                                )}
                                <Badge variant="outline" className={`shrink-0 text-xs ${selected ? 'border-red-500 text-red-600' : ''}`}>{detailItem.code}</Badge>
                                <span className={`text-sm ${selected ? 'text-red-700 dark:text-red-300 font-medium' : ''}`}>{detailItem.name}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                    
                    {/* 如果没有详细数据，显示提示 */}
                    {isExpanded && detailedItems.length === 0 && (
                      <div className="border-t bg-white dark:bg-gray-900 p-4 text-center text-gray-500">
                        暂无详细商品数据
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* 相关分类推荐 */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle className="text-lg">相关分类</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-5 sm:grid-cols-9 md:grid-cols-12 gap-2">
              {trademarkCategories
                .filter(c => c.id !== categoryId)
                .slice(0, 10)
                .map(cat => (
                  <Link key={cat.id} href={`/category/${cat.id}`}>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full text-xs hover:bg-red-50 dark:hover:bg-red-900 hover:text-red-600 hover:border-red-300"
                    >
                      第{cat.id}类
                    </Button>
                  </Link>
                ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 底部固定工具栏 */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t shadow-lg z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={() => setShowCart(!showCart)}
              className="relative"
            >
              <ShoppingCart className="w-5 h-5" />
              {selectedItems.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {selectedItems.length}
                </span>
              )}
            </Button>
            <Button
              onClick={copyToClipboard}
              disabled={selectedItems.length === 0}
              className={`bg-red-600 hover:bg-red-700 ${selectedItems.length === 0 ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {copySuccess ? (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  已复制
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  复制 {selectedItems.length} 个商品
                </>
              )}
            </Button>
          </div>
          <div className="text-sm text-gray-500">
            已选择 {selectedItems.length} 个商品
          </div>
        </div>
      </div>

      {/* 购物车弹窗 */}
      {showCart && (
        <>
          {/* 遮罩层 */}
          <div 
            className="fixed inset-0 bg-black/30 z-40"
            onClick={() => setShowCart(false)}
          />
          
          {/* 购物车面板 */}
          <div className="fixed bottom-16 right-4 w-80 max-h-[70vh] bg-white dark:bg-gray-900 rounded-lg shadow-xl border z-50 flex flex-col">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="font-semibold text-lg">已选商品 ({selectedItems.length})</h3>
              <div className="flex items-center gap-2">
                {selectedItems.length > 0 && (
                  <Button variant="ghost" size="sm" onClick={clearAll} className="text-red-600 hover:text-red-700 hover:bg-red-50">
                    <Trash2 className="w-4 h-4 mr-1" />
                    清空
                  </Button>
                )}
                <Button variant="ghost" size="sm" onClick={() => setShowCart(false)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4">
              {selectedItems.length === 0 ? (
                <div className="text-center text-gray-500 py-8">
                  <ShoppingCart className="w-12 h-12 mx-auto mb-2 opacity-30" />
                  <p>暂无选择商品</p>
                  <p className="text-sm mt-1">点击商品可添加到列表</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {selectedItems.map(item => (
                    <div 
                      key={item.code}
                      className="flex items-start justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded group"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs shrink-0">{item.code}</Badge>
                          <Badge variant="secondary" className="text-xs">{item.subCode}</Badge>
                        </div>
                        <p className="text-sm mt-1 truncate">{item.name}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeItem(item.code)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity text-red-600 hover:text-red-700 hover:bg-red-50 shrink-0"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            {selectedItems.length > 0 && (
              <div className="p-4 border-t">
                <Button 
                  onClick={copyToClipboard} 
                  className="w-full bg-red-600 hover:bg-red-700"
                >
                  {copySuccess ? (
                    <>
                      <Check className="w-4 h-4 mr-2" />
                      已复制到剪贴板
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 mr-2" />
                      复制全部 ({selectedItems.length}项)
                    </>
                  )}
                </Button>
              </div>
            )}
          </div>
        </>
      )}

      {/* 底部信息 */}
      <div className="bg-gray-100 dark:bg-gray-900 border-t mt-8 py-6">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-gray-600 dark:text-gray-400">
          <p>ABC商标分类查询系统 - 基于2026版尼斯分类</p>
          <p className="mt-2">
            Copyright © 2024 ABC All Right Reserved
          </p>
        </div>
      </div>
    </div>
  );
}
