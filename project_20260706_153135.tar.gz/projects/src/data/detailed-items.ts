// 细化商品数据 - 基于尼斯分类2026版
// 统一导出入口，避免循环依赖

// 从整合文件中导出所有内容
export { 
  allCategoriesDetail,
  allDetailedCategories,
  getDetailByCategoryId,
  searchItems,
  searchItemsInCategory,
  type DetailedItem,
  type SubCategoryDetail
} from './all-categories-detail';
