// 统一导出所有商标分类详细数据
import { SubCategoryDetail } from './types';

import { category1Detail } from './trademark-category-1';
import { category2Detail } from './trademark-category-2';
import { category3Detail } from './trademark-category-3';
import { category4Detail } from './trademark-category-4';
import { category5Detail } from './trademark-category-5';
import { category6Detail } from './trademark-category-6';
import { category7Detail } from './trademark-category-7';
import { category8Detail } from './trademark-category-8';
import { category9Detail } from './trademark-category-9';
import { category10Detail } from './trademark-category-10';
import { category11Detail } from './trademark-category-11';
import { category12Detail } from './trademark-category-12';
import { category13Detail } from './trademark-category-13';
import { category14Detail } from './trademark-category-14';
import { category15Detail } from './trademark-category-15';
import { category16Detail } from './trademark-category-16';
import { category17Detail } from './trademark-category-17';
import { category18Detail } from './trademark-category-18';
import { category19Detail } from './trademark-category-19';
import { category20Detail } from './trademark-category-20';
import { category21Detail } from './trademark-category-21';
import { category22Detail } from './trademark-category-22';
import { category23Detail } from './trademark-category-23';
import { category24Detail } from './trademark-category-24';
import { category25Detail } from './trademark-category-25';
import { category26Detail } from './trademark-category-26';
import { category27Detail } from './trademark-category-27';
import { category28Detail } from './trademark-category-28';
import { category29Detail } from './trademark-category-29';
import { category30Detail } from './trademark-category-30';
import { category31Detail } from './trademark-category-31';
import { category32Detail } from './trademark-category-32';
import { category33Detail } from './trademark-category-33';
import { category34Detail } from './trademark-category-34';
import { category35Detail } from './trademark-category-35';
import { category36Detail } from './trademark-category-36';
import { category37Detail } from './trademark-category-37';
import { category38Detail } from './trademark-category-38';
import { category39Detail } from './trademark-category-39';
import { category40Detail } from './trademark-category-40';
import { category41Detail } from './trademark-category-41';
import { category42Detail } from './trademark-category-42';
import { category43Detail } from './trademark-category-43';
import { category44Detail } from './trademark-category-44';
import { category45Detail } from './trademark-category-45';

// 导出所有分类数据
export const allCategoryDetails: Record<number, SubCategoryDetail[]> = {
  1: category1Detail,
  2: category2Detail,
  3: category3Detail,
  4: category4Detail,
  5: category5Detail,
  6: category6Detail,
  7: category7Detail,
  8: category8Detail,
  9: category9Detail,
  10: category10Detail,
  11: category11Detail,
  12: category12Detail,
  13: category13Detail,
  14: category14Detail,
  15: category15Detail,
  16: category16Detail,
  17: category17Detail,
  18: category18Detail,
  19: category19Detail,
  20: category20Detail,
  21: category21Detail,
  22: category22Detail,
  23: category23Detail,
  24: category24Detail,
  25: category25Detail,
  26: category26Detail,
  27: category27Detail,
  28: category28Detail,
  29: category29Detail,
  30: category30Detail,
  31: category31Detail,
  32: category32Detail,
  33: category33Detail,
  34: category34Detail,
  35: category35Detail,
  36: category36Detail,
  37: category37Detail,
  38: category38Detail,
  39: category39Detail,
  40: category40Detail,
  41: category41Detail,
  42: category42Detail,
  43: category43Detail,
  44: category44Detail,
  45: category45Detail,
};

// 获取指定分类的详细数据
export function getCategoryDetail(categoryId: number): SubCategoryDetail[] | undefined {
  return allCategoryDetails[categoryId];
}

// 搜索商品
export function searchItems(keyword: string, categoryId?: number) {
  const results: Array<{ categoryId: number; subcategoryCode: string; item: { code: string; name: string } }> = [];
  const lowerKeyword = keyword.toLowerCase();
  
  const categoriesToSearch = categoryId ? [categoryId] : Object.keys(allCategoryDetails).map(Number);
  
  for (const catId of categoriesToSearch) {
    const subcategories = allCategoryDetails[catId];
    if (!subcategories) continue;
    
    for (const subcat of subcategories) {
      for (const item of subcat.items) {
        if (item.name.toLowerCase().includes(lowerKeyword) || item.code.includes(keyword)) {
          results.push({ categoryId: catId, subcategoryCode: subcat.code, item });
        }
      }
    }
  }
  
  return results;
}
