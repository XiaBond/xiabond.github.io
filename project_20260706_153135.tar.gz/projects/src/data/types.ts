// 商标分类数据类型定义
// 避免循环依赖，独立定义类型

export interface DetailedItem {
  code: string;
  name: string;
}

export interface SubCategoryDetail {
  code: string;
  title: string;
  items: DetailedItem[];
}
