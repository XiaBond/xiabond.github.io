// 第27类详细商品数据
// 地毯，地席，席类，油毡及其他铺地板材料；非纺织品制墙帷。

import { SubCategoryDetail } from './types';

export const category27Detail: SubCategoryDetail[] = [
  {
    code: "2701",
    title: "地毯",
    items: [
      { code: "270011", name: "地毯" },
      { code: "270011", name: "小地毯" },
    ]
  },
  {
    code: "2702",
    title: "席类",
    items: [
      { code: "270006", name: "垫席" },
      { code: "270009", name: "苇席" },
    ]
  },
  {
    code: "2703",
    title: "垫及其他可移动铺地板用品",
    items: [
      { code: "270001", name: "浴室防滑垫" },
      { code: "270002", name: "地板覆盖物" },
      { code: "270003", name: "人工草皮" },
      { code: "270004", name: "体操垫" },
      { code: "270004", name: "健身用垫" },
      { code: "270008", name: "门前擦鞋垫" },
      { code: "270010", name: "汽车用脚垫" },
      { code: "270012", name: "防滑垫" },
      { code: "270014", name: "油毡制地板覆盖物" },
      { code: "270015", name: "地毯底衬" },
      { code: "270016", name: "乙烯地板覆盖物" },
      { code: "270017", name: "滑雪斜坡用编织绳垫" },
      { code: "270019", name: "壁炉或烧烤架用耐火地垫" },
      { code: "270020", name: "瑜伽垫" },
      { code: "270021", name: "榻榻米垫" },
      { code: "270023", name: "油毡块（地板覆盖物）" },
      { code: "270024", name: "祈祷跪垫" },
      { code: "270025", name: "橡胶地垫" },
      { code: "270026", name: "运载工具用地垫" },
      { code: "270028", name: "瑜伽垫专用包" },
      { code: "270029", name: "打坐地垫" },
    ]
  },
  {
    code: "2704",
    title: "非纺织墙帷，墙纸及非纺织挂毯",
    items: [
      { code: "270007", name: "墙纸" },
      { code: "270013", name: "非纺织品制壁挂" },
      { code: "270018", name: "纺织品制墙纸" },
      { code: "270022", name: "纺织品制墙壁遮盖物" },
      { code: "270027", name: "人造植物制墙壁覆盖物" },
    ]
  },
];