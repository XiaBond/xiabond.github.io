// 第34类详细商品数据
// 烟草；烟具；火柴。

import { SubCategoryDetail } from './types';

export const category34Detail: SubCategoryDetail[] = [
  {
    code: "3401",
    title: "烟草及其制品",
    items: [
      { code: "340003", name: "烟草" },
      { code: "340012", name: "嚼烟" },
      { code: "340013", name: "雪茄" },
      { code: "340019", name: "非医用含烟草代用品的香烟" },
      { code: "340020", name: "香烟" },
      { code: "340025", name: "小雪茄" },
      { code: "340028", name: "烟用草本植物" },
      { code: "340033", name: "鼻烟" },
      { code: "340047", name: "用作烟草代用品的尼古丁袋（非医用）" },
    ]
  },
  {
    code: "3402",
    title: "烟具",
    items: [
      { code: "340002", name: "雪茄及香烟烟嘴上黄琥珀烟嘴头" },
      { code: "340004", name: "烟袋" },
      { code: "340005", name: "香烟嘴" },
      { code: "340009", name: "烟斗" },
      { code: "340014", name: "雪茄切刀" },
      { code: "340015", name: "雪茄烟盒" },
      { code: "340016", name: "香烟盒" },
      { code: "340017", name: "雪茄烟嘴" },
      { code: "340021", name: "袖珍卷烟器" },
      { code: "340022", name: "香烟烟嘴" },
      { code: "340023", name: "香烟烟嘴头" },
      { code: "340026", name: "烟斗通条" },
      { code: "340030", name: "烟斗搁架" },
      { code: "340032", name: "烟草罐" },
      { code: "340034", name: "鼻烟壶" },
      { code: "340036", name: "烟灰缸" },
      { code: "340037", name: "吸烟者用痰盂" },
      { code: "340038", name: "（防止烟草变干的）保润盒" },
      { code: "340045", name: "水烟袋" },
      { code: "340046", name: "吸入型烟草用加热设备" },
    ]
  },
  {
    code: "3403",
    title: "火柴",
    items: [
      { code: "340001", name: "火柴" },
      { code: "340031", name: "火柴架" },
      { code: "340035", name: "火柴盒" },
    ]
  },
  {
    code: "3404",
    title: "吸烟用打火机",
    items: [
      { code: "340007", name: "吸烟用打火机" },
      { code: "340008", name: "点烟器用气罐" },
      { code: "340044", name: "吸烟打火机用火芯" },
    ]
  },
  {
    code: "3405",
    title: "烟纸，过滤嘴",
    items: [
      { code: "340006", name: "香烟过滤嘴" },
      { code: "340010", name: "小本卷烟纸" },
      { code: "340011", name: "烟斗吸水纸" },
      { code: "340024", name: "卷烟纸" },
    ]
  },
  {
    code: "3406",
    title: "香烟用调味品",
    items: [
      { code: "340042", name: "烟草用调味品" },
      { code: "340042", name: "除香精油外的烟草用调味品" },
      { code: "340043", name: "除香精油外的电子烟用调味品" },
    ]
  },
  {
    code: "3407",
    title: "电子香烟及其部件",
    items: [
      { code: "340039", name: "电子烟" },
      { code: "340040", name: "电子烟用烟液" },
      { code: "340041", name: "吸烟者用口腔雾化器" },
    ]
  },
];