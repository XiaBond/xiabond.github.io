// 第23类详细商品数据
// 纺织用纱和线。

import { SubCategoryDetail } from './types';

export const category23Detail: SubCategoryDetail[] = [
  {
    code: "2301",
    title: "纺织用纱、丝",
    items: [
      { code: "230002", name: "棉线和棉纱" },
      { code: "230003", name: "绣花用线和纱" },
      { code: "230004", name: "毛线和粗纺毛纱" },
      { code: "230005", name: "麻线和纱" },
      { code: "230006", name: "椰纤维线和纱" },
      { code: "230007", name: "丝线和纱" },
      { code: "230008", name: "精纺棉" },
      { code: "230009", name: "缝纫线和纱" },
      { code: "230010", name: "细线和细纱" },
      { code: "230011", name: "黄麻线和纱" },
      { code: "230012", name: "精纺羊毛" },
      { code: "230013", name: "亚麻线和纱" },
      { code: "230014", name: "人造线和纱" },
      { code: "230015", name: "纺织线和纱" },
      { code: "230016", name: "绢丝" },
      { code: "230019", name: "纺织用弹性线和纱" },
    ]
  },
  {
    code: "2302",
    title: "线",
    items: [
      { code: "230002", name: "棉线和棉纱" },
      { code: "230003", name: "绣花用线和纱" },
      { code: "230005", name: "麻线和纱" },
      { code: "230006", name: "椰纤维线和纱" },
      { code: "230007", name: "丝线和纱" },
      { code: "230009", name: "缝纫线和纱" },
      { code: "230010", name: "细线和细纱" },
      { code: "230011", name: "黄麻线和纱" },
      { code: "230013", name: "亚麻线和纱" },
      { code: "230014", name: "人造线和纱" },
      { code: "230015", name: "纺织线和纱" },
      { code: "230017", name: "纺织用玻璃纤维线" },
      { code: "230018", name: "纺织用橡皮线" },
      { code: "230019", name: "纺织用弹性线和纱" },
      { code: "230020", name: "纺织用塑料线" },
      { code: "230032", name: "刺绣用金属线" },
    ]
  },
  {
    code: "2303",
    title: "毛线",
    items: [
      { code: "230004", name: "毛线和粗纺毛纱" },
      { code: "230012", name: "毛线" },
      { code: "230031", name: "绳绒线" },
    ]
  },
];