// 第33类详细商品数据
// 含酒精的饮料（啤酒除外）。

import { SubCategoryDetail } from './types';

export const category33Detail: SubCategoryDetail[] = [
  {
    code: "3301",
    title: "含酒精的饮料（啤酒除外）",
    items: [
      { code: "330001", name: "薄荷酒" },
      { code: "330002", name: "果酒（含酒精）" },
      { code: "330003", name: "苦味酒" },
      { code: "330004", name: "茴芹酒（利口酒）" },
      { code: "330005", name: "茴香酒（利口酒）" },
      { code: "330006", name: "开胃酒" },
      { code: "330007", name: "亚力酒" },
      { code: "330008", name: "蒸馏饮料" },
      { code: "330009", name: "苹果酒" },
      { code: "330010", name: "鸡尾酒" },
      { code: "330011", name: "柑香酒" },
      { code: "330012", name: "餐后酒（利口酒和烈酒）" },
      { code: "330013", name: "葡萄酒" },
      { code: "330014", name: "杜松子酒" },
      { code: "330015", name: "利口酒" },
      { code: "330016", name: "蜂蜜酒" },
      { code: "330017", name: "樱桃酒" },
      { code: "330018", name: "烈酒（饮料）" },
      { code: "330019", name: "白兰地" },
      { code: "330020", name: "酸酒（低等葡萄酒）" },
      { code: "330021", name: "梨酒" },
      { code: "330022", name: "清酒（日本米酒）" },
      { code: "330023", name: "威士忌" },
      { code: "330024", name: "酒精饮料原汁" },
      { code: "330025", name: "酒精饮料浓缩汁" },
      { code: "330026", name: "酒精饮料（啤酒除外）" },
      { code: "330031", name: "含水果酒精饮料" },
      { code: "330032", name: "米酿制的酒精饮料" },
      { code: "330033", name: "朗姆酒" },
      { code: "330034", name: "伏特加酒" },
      { code: "330035", name: "预先混合的酒精饮料（以啤酒为主的除外）" },
      { code: "330036", name: "甘蔗制酒精饮料" },
      { code: "330037", name: "谷物制蒸馏酒精饮料" },
      { code: "330038", name: "以葡萄酒为主的饮料" },
      { code: "330039", name: "烧酒" },
      { code: "330040", name: "朝鲜族米酒" },
      { code: "330041", name: "含酒精的气泡水" },
      { code: "330042", name: "已调味的麦芽酿制的酒精饮料（啤酒除外）" },
      { code: "330043", name: "米酒" },
    ]
  },
];