// 统一导出所有类别的详细商品数据
// 数据来源：sbfl.cn，基于尼斯分类2026版

// 从独立类型文件导入类型
export type { DetailedItem, SubCategoryDetail } from './types';

// 从新的数据文件导入
import { allCategoryDetails, getCategoryDetail, searchItems as searchItemsNew } from './trademark-all-categories';

// 导出详细数据
export const allCategoriesDetail: Record<number, import('./types').SubCategoryDetail[]> = allCategoryDetails;

// 为了兼容性，导出别名
export const allDetailedCategories = allCategoriesDetail;

// 根据类别ID获取详细商品数据
export function getDetailByCategoryId(categoryId: number): import('./types').SubCategoryDetail[] | undefined {
  return getCategoryDetail(categoryId);
}

// 搜索商品（在所有类别中搜索）
export function searchItems(keyword: string): Array<{
  categoryId: number;
  categoryName: string;
  subCategoryCode: string;
  subCategoryTitle: string;
  item: import('./types').DetailedItem;
}> {
  // 类别名称映射
  const categoryNames: Record<number, string> = {
    1: "化学品",
    2: "颜料、清漆、漆",
    3: "肥皂、香料、化妆品",
    4: "工业用油和油脂",
    5: "药品",
    6: "普通金属及其合金",
    7: "机器和机床",
    8: "手工具和器具",
    9: "科学、研究仪器",
    10: "医疗器械",
    11: "照明、加热设备",
    12: "运载工具",
    13: "火器",
    14: "贵金属、首饰",
    15: "乐器",
    16: "纸张、文具",
    17: "橡胶、塑料",
    18: "皮革、箱包",
    19: "非金属建筑材料",
    20: "家具",
    21: "厨房用具",
    22: "绳索、网",
    23: "纺织用纱和线",
    24: "织物",
    25: "服装、鞋、帽",
    26: "花边、扣子",
    27: "地毯、席垫",
    28: "健身器材",
    29: "肉、鱼、禽",
    30: "调味品、茶",
    31: "农业、园艺产品",
    32: "啤酒、饮料",
    33: "酒",
    34: "烟草",
    35: "广告、商业经营",
    36: "金融、保险",
    37: "建筑、修理",
    38: "通讯服务",
    39: "运输、旅行",
    40: "材料加工",
    41: "教育、培训",
    42: "科技服务",
    43: "餐饮、住宿",
    44: "医疗、美容",
    45: "法律、安全"
  };

  const results: Array<{
    categoryId: number;
    categoryName: string;
    subCategoryCode: string;
    subCategoryTitle: string;
    item: import('./types').DetailedItem;
  }> = [];

  const searchResults = searchItemsNew(keyword);
  
  // 需要从subcategory code推断title
  for (const result of searchResults) {
    const subcatDetail = allCategoriesDetail[result.categoryId]?.find(s => s.code === result.subcategoryCode);
    results.push({
      categoryId: result.categoryId,
      categoryName: categoryNames[result.categoryId] || '',
      subCategoryCode: result.subcategoryCode,
      subCategoryTitle: subcatDetail?.title || '',
      item: result.item
    });
  }

  return results;
}

// 在特定类别的详细商品中搜索
export function searchItemsInCategory(
  categoryId: number, 
  keyword: string
): Array<{
  subCategoryCode: string;
  subCategoryTitle: string;
  item: import('./types').DetailedItem;
}> {
  const results: Array<{
    subCategoryCode: string;
    subCategoryTitle: string;
    item: import('./types').DetailedItem;
  }> = [];

  const categoryDetail = allCategoriesDetail[categoryId];
  if (!categoryDetail) return results;

  const lowerKeyword = keyword.toLowerCase();

  categoryDetail.forEach(subCategory => {
    subCategory.items.forEach(item => {
      if (item.name.toLowerCase().includes(lowerKeyword) || 
          item.code.includes(keyword)) {
        results.push({
          subCategoryCode: subCategory.code,
          subCategoryTitle: subCategory.title,
          item: item
        });
      }
    });
  });

  return results;
}
