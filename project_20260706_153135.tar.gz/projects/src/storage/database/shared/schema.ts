import { pgTable, serial, timestamp, varchar, text, index } from "drizzle-orm/pg-core"
import { sql } from "drizzle-orm"



export const healthCheck = pgTable("health_check", {
	id: serial().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});

// 尼斯分类商品服务表（2026版）
export const nclGoodsServices = pgTable(
  "ncl_goods_services",
  {
    id: serial().primaryKey(),
    class: varchar("class", { length: 10 }).notNull(),
    basic_no: varchar("basic_no", { length: 20 }).notNull(),
    en_description: text("en_description"),
    jpo_acceptable: varchar("jpo_acceptable", { length: 10 }),
    japanese_translation: text("japanese_translation"),
    jpo_similar_group_code: varchar("jpo_similar_group_code", { length: 20 }),
    moip_acceptable: varchar("moip_acceptable", { length: 10 }),
    korean_translation: text("korean_translation"),
    moip_similar_group_code: varchar("moip_similar_group_code", { length: 20 }),
    cnipa_acceptable: varchar("cnipa_acceptable", { length: 10 }),
    chinese_translation: text("chinese_translation"),
    cnipa_similar_group_code: varchar("cnipa_similar_group_code", { length: 20 }),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("ncl_class_idx").on(table.class),
    index("ncl_basic_no_idx").on(table.basic_no),
    index("ncl_cnipa_group_idx").on(table.cnipa_similar_group_code),
  ]
);
