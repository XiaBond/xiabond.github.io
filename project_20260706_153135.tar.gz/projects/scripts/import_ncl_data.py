#!/usr/bin/env python3
"""
导入尼斯分类商品服务数据到Supabase数据库
"""

import os
import sys
import json
import openpyxl
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 获取Supabase配置
SUPABASE_URL = os.environ.get('COZE_SUPABASE_URL')
SUPABASE_SERVICE_ROLE_KEY = os.environ.get('COZE_SUPABASE_SERVICE_ROLE_KEY')
SUPABASE_ANON_KEY = os.environ.get('COZE_SUPABASE_ANON_KEY')

if not SUPABASE_URL:
    print("Error: COZE_SUPABASE_URL not set")
    sys.exit(1)

# 优先使用service_role_key
API_KEY = SUPABASE_SERVICE_ROLE_KEY or SUPABASE_ANON_KEY
if not API_KEY:
    print("Error: No Supabase API key found")
    sys.exit(1)

print(f"Using Supabase URL: {SUPABASE_URL}")
print(f"Using API key type: {'service_role' if SUPABASE_SERVICE_ROLE_KEY else 'anon'}")

def read_excel(file_path):
    """读取Excel文件"""
    wb = openpyxl.load_workbook(file_path, data_only=True)
    ws = wb[wb.sheetnames[0]]
    
    # 跳过表头，读取数据
    data = []
    for i, row in enumerate(ws.iter_rows(min_row=2, values_only=True), 2):
        if row[0] is None:  # 跳过空行
            continue
        
        item = {
            'class': str(row[0]).strip() if row[0] else None,
            'basic_no': str(row[1]).strip() if row[1] else None,
            'en_description': str(row[2]).strip() if row[2] else None,
            'jpo_acceptable': str(row[3]).strip() if row[3] else None,
            'japanese_translation': str(row[4]).strip() if row[4] else None,
            'jpo_similar_group_code': str(row[5]).strip() if row[5] else None,
            'moip_acceptable': str(row[6]).strip() if row[6] else None,
            'korean_translation': str(row[7]).strip() if row[7] else None,
            'moip_similar_group_code': str(row[8]).strip() if row[8] else None,
            'cnipa_acceptable': str(row[9]).strip() if row[9] else None,
            'chinese_translation': str(row[10]).strip() if row[10] else None,
            'cnipa_similar_group_code': str(row[11]).strip() if row[11] else None,
        }
        data.append(item)
        
        if i % 2000 == 0:
            print(f"Read {i} rows...")
    
    return data

def batch_insert(data, batch_size=100):
    """分批插入数据到Supabase"""
    import urllib.request
    import urllib.error
    
    total = len(data)
    inserted = 0
    failed = 0
    
    for i in range(0, total, batch_size):
        batch = data[i:i + batch_size]
        
        payload = json.dumps(batch).encode('utf-8')
        
        req = urllib.request.Request(
            f"{SUPABASE_URL}/rest/v1/ncl_goods_services",
            data=payload,
            headers={
                'Content-Type': 'application/json',
                'apikey': API_KEY,
                'Authorization': f'Bearer {API_KEY}',
                'Prefer': 'return=minimal'
            },
            method='POST'
        )
        
        try:
            with urllib.request.urlopen(req) as response:
                if response.status in (200, 201):
                    inserted += len(batch)
                    print(f"Progress: {inserted}/{total} ({inserted*100//total}%)")
                else:
                    print(f"Batch {i//batch_size + 1} failed with status {response.status}")
                    failed += len(batch)
        except urllib.error.HTTPError as e:
            error_body = e.read().decode('utf-8')
            print(f"Batch {i//batch_size + 1} failed: {e.code} - {error_body[:200]}")
            failed += len(batch)
        except Exception as e:
            print(f"Batch {i//batch_size + 1} error: {e}")
            failed += len(batch)
    
    return inserted, failed

def main():
    file_path = '/tmp/import_data.xlsx'
    
    if not os.path.exists(file_path):
        print(f"Error: File not found: {file_path}")
        sys.exit(1)
    
    print("Reading Excel file...")
    data = read_excel(file_path)
    print(f"Total rows to insert: {len(data)}")
    
    print("\nInserting data...")
    inserted, failed = batch_insert(data, batch_size=100)
    
    print(f"\n=== Import Complete ===")
    print(f"Inserted: {inserted}")
    print(f"Failed: {failed}")
    print(f"Total: {len(data)}")

if __name__ == '__main__':
    main()
