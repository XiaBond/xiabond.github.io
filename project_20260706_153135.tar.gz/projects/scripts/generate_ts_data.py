#!/usr/bin/env python3
"""
合并商标数据并生成TypeScript文件
"""

import json
import os

def load_json_files():
    """加载所有JSON数据文件"""
    data_dir = os.environ.get('COZE_WORKSPACE_PATH', '/workspace/projects') + '/src/data'
    
    all_data = {}
    
    for filename in ['trademark-detail-1-15.json', 'trademark-detail-16-30.json', 'trademark-detail-31-45.json']:
        filepath = os.path.join(data_dir, filename)
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
                all_data.update(data)
                print(f"加载 {filename}: {len(data)} 个分类")
    
    return all_data

def generate_typescript(all_data):
    """生成TypeScript数据文件"""
    output = []
    output.append("// 商标分类详细商品数据 - 基于尼斯分类2026版")
    output.append("// 数据来源: sbfl.cn")
    output.append("")
    output.append("import { SubCategoryDetail } from './all-categories-detail';")
    output.append("")
    
    for cat_id in sorted(all_data.keys()):
        cat = all_data[cat_id]
        output.append(f"// 第{cat_id}类")
        output.append(f"export const category{cat_id}Detail: SubCategoryDetail[] = [")
        
        for subcat in cat['subcategories']:
            output.append("  {")
            output.append(f'    code: "{subcat["code"]}",')
            output.append(f'    title: "{subcat["title"]}",')
            output.append("    items: [")
            
            for item in subcat['items']:
                output.append(f'      {{ code: "{item["code"]}", name: "{item["name"]}" }},')
            
            output.append("    ]")
            output.append("  },")
        
        output.append("];")
        output.append("")
    
    return '\n'.join(output)

def generate_index_file(all_data):
    """生成索引文件，导出所有分类数据"""
    output = []
    output.append("// 统一导出所有商标分类详细数据")
    output.append("import { SubCategoryDetail } from './all-categories-detail';")
    output.append("")
    
    # 导入各分类
    for cat_id in sorted(all_data.keys()):
        output.append(f"import {{ category{cat_id}Detail }} from './trademark-category-{cat_id}';")
    
    output.append("")
    output.append("// 导出所有分类数据")
    output.append("export const allCategoryDetails: Record<number, SubCategoryDetail[]> = {")
    
    for cat_id in sorted(all_data.keys()):
        output.append(f"  {cat_id}: category{cat_id}Detail,")
    
    output.append("};")
    output.append("")
    output.append("// 获取指定分类的详细数据")
    output.append("export function getCategoryDetail(categoryId: number): SubCategoryDetail[] | undefined {")
    output.append("  return allCategoryDetails[categoryId];")
    output.append("}")
    output.append("")
    output.append("// 搜索商品")
    output.append("export function searchItems(keyword: string, categoryId?: number) {")
    output.append("  const results: Array<{ categoryId: number; subcategoryCode: string; item: { code: string; name: string } }> = [];")
    output.append("  const lowerKeyword = keyword.toLowerCase();")
    output.append("  ")
    output.append("  const categoriesToSearch = categoryId ? [categoryId] : Object.keys(allCategoryDetails).map(Number);")
    output.append("  ")
    output.append("  for (const catId of categoriesToSearch) {")
    output.append("    const subcategories = allCategoryDetails[catId];")
    output.append("    if (!subcategories) continue;")
    output.append("    ")
    output.append("    for (const subcat of subcategories) {")
    output.append("      for (const item of subcat.items) {")
    output.append("        if (item.name.toLowerCase().includes(lowerKeyword) || item.code.includes(keyword)) {")
    output.append("          results.push({ categoryId: catId, subcategoryCode: subcat.code, item });")
    output.append("        }")
    output.append("      }")
    output.append("    }")
    output.append("  }")
    output.append("  ")
    output.append("  return results;")
    output.append("}")
    
    return '\n'.join(output)

def generate_single_category_file(cat_id, cat_data):
    """生成单个分类的TypeScript文件"""
    output = []
    output.append(f"// 第{cat_id}类详细商品数据")
    output.append(f"// {cat_data['description']}")
    output.append("")
    output.append("import { SubCategoryDetail } from './all-categories-detail';")
    output.append("")
    output.append(f"export const category{cat_id}Detail: SubCategoryDetail[] = [")
    
    for subcat in cat_data['subcategories']:
        output.append("  {")
        output.append(f'    code: "{subcat["code"]}",')
        output.append(f'    title: "{subcat["title"]}",')
        output.append("    items: [")
        
        for item in subcat['items']:
            # 转义特殊字符
            name = item['name'].replace('\\', '\\\\').replace('"', '\\"')
            output.append(f'      {{ code: "{item["code"]}", name: "{name}" }},')
        
        output.append("    ]")
        output.append("  },")
    
    output.append("];")
    
    return '\n'.join(output)

def main():
    print("加载数据...")
    all_data = load_json_files()
    print(f"共加载 {len(all_data)} 个分类")
    
    # 统计
    total_items = sum(len(i['items']) for c in all_data.values() for i in c['subcategories'])
    total_subcats = sum(len(c['subcategories']) for c in all_data.values())
    print(f"共 {total_subcats} 个小类, {total_items} 个商品")
    
    output_dir = os.environ.get('COZE_WORKSPACE_PATH', '/workspace/projects') + '/src/data'
    
    # 生成各分类文件
    print("\n生成分类文件...")
    for cat_id in sorted(all_data.keys()):
        cat_data = all_data[cat_id]
        content = generate_single_category_file(cat_id, cat_data)
        filepath = os.path.join(output_dir, f'trademark-category-{cat_id}.ts')
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"  生成 trademark-category-{cat_id}.ts")
    
    # 生成索引文件
    print("\n生成索引文件...")
    index_content = generate_index_file(all_data)
    index_path = os.path.join(output_dir, 'trademark-all-categories.ts')
    with open(index_path, 'w', encoding='utf-8') as f:
        f.write(index_content)
    print(f"  生成 trademark-all-categories.ts")
    
    # 合并保存完整JSON
    json_path = os.path.join(output_dir, 'trademark-complete-data.json')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(all_data, f, ensure_ascii=False, indent=2)
    print(f"  生成 trademark-complete-data.json")
    
    print("\n完成!")

if __name__ == '__main__':
    main()
