#!/usr/bin/env python3
"""
商标分类数据抓取脚本 - 快速版
从 sbfl.cn 获取2026版尼斯分类详细商品数据
"""

import requests
import re
import json
import time
import os
import sys

BASE_URL = "http://www.sbfl.cn"
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}

def get_page(url, encoding='gb2312'):
    """获取页面内容"""
    try:
        resp = requests.get(url, headers=HEADERS, timeout=15)
        resp.encoding = encoding
        return resp.text
    except Exception as e:
        print(f"Error: {e}")
        return None

def parse_main_page(html):
    """解析首页，获取所有分类和小类"""
    categories = {}
    
    # 匹配分类标题
    category_pattern = r'【第(\d+)类】\s*([^<]+)</b></a>'
    for cat_id, cat_desc in re.findall(category_pattern, html):
        categories[int(cat_id)] = {
            'id': int(cat_id),
            'description': cat_desc.strip(),
            'subcategories': {}
        }
    
    # 匹配小类链接
    subcat_pattern = r'href="(\d+)-(\d{4})\.html"[^>]*>(\d{4})-([^<]+)</a>'
    for cat_id, subcode, _, subname in re.findall(subcat_pattern, html):
        cat_id = int(cat_id)
        if cat_id in categories:
            categories[cat_id]['subcategories'][subcode] = subname.strip()
    
    return categories

def parse_items(content):
    """解析商品列表"""
    items = []
    # 商品格式：商品名010001；
    item_pattern = r'([^；;，,\d\s][^；;，,]*?)(\d{6})[；;，,]?'
    for name, code in re.findall(item_pattern, content):
        name = name.strip()
        if name and code and len(name) > 1:
            items.append({'code': code, 'name': name})
    return items

def fetch_category_data(cat_id, subcats):
    """获取一个分类下所有小类的数据"""
    results = []
    for subcode in sorted(subcats.keys()):
        url = f"{BASE_URL}/{cat_id}-{subcode}.html"
        html = get_page(url, 'utf-8')
        
        if html:
            # 提取商品内容
            match = re.search(r'<div class="sbflnr"[^>]*>(.*?)</div>', html, re.DOTALL)
            if match:
                items = parse_items(match.group(1))
                results.append({
                    'code': subcode,
                    'title': subcats[subcode],
                    'items': items
                })
                print(f"      {subcode}: {len(items)} 个商品", flush=True)
            else:
                results.append({'code': subcode, 'title': subcats[subcode], 'items': []})
                print(f"      {subcode}: 未找到内容", flush=True)
        else:
            results.append({'code': subcode, 'title': subcats[subcode], 'items': []})
            print(f"      {subcode}: 获取失败", flush=True)
        
        time.sleep(0.1)  # 短暂延迟
    
    return results

def main():
    output_dir = os.environ.get('COZE_WORKSPACE_PATH', '/workspace/projects') + '/src/data'
    os.makedirs(output_dir, exist_ok=True)
    
    print("获取首页...", flush=True)
    html = get_page(BASE_URL, 'gb2312')
    if not html:
        print("获取首页失败!")
        return
    
    print("解析分类结构...", flush=True)
    categories = parse_main_page(html)
    print(f"找到 {len(categories)} 个分类, {sum(len(c['subcategories']) for c in categories.values())} 个小类", flush=True)
    
    # 抓取数据
    all_data = {}
    start_cat = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    end_cat = int(sys.argv[2]) if len(sys.argv) > 2 else 45
    
    for cat_id in sorted(categories.keys()):
        if cat_id < start_cat or cat_id > end_cat:
            continue
            
        cat = categories[cat_id]
        print(f"\n第{cat_id}类...", flush=True)
        
        all_data[cat_id] = {
            'id': cat_id,
            'description': cat['description'],
            'subcategories': fetch_category_data(cat_id, cat['subcategories'])
        }
    
    # 保存数据
    output_file = os.path.join(output_dir, f'trademark-detail-{start_cat}-{end_cat}.json')
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_data, f, ensure_ascii=False, indent=2)
    
    total_items = sum(len(i['items']) for c in all_data.values() for i in c['subcategories'])
    print(f"\n完成! 分类: {len(all_data)}, 商品: {total_items}")
    print(f"保存到: {output_file}")

if __name__ == '__main__':
    main()
