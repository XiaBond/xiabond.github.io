#!/usr/bin/env python3
"""
商标分类数据抓取脚本
从 sbfl.cn 获取2026版尼斯分类详细商品数据
"""

import requests
import re
import json
import time
import os

BASE_URL = "http://www.sbfl.cn"
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}

def get_main_page():
    """获取首页内容"""
    resp = requests.get(BASE_URL, headers=HEADERS, timeout=30)
    resp.encoding = 'gb2312'
    return resp.text

def parse_main_page(html):
    """解析首页，获取所有分类和小类的链接"""
    categories = {}
    
    # 匹配分类和小类的链接，格式如: 1-0101.html
    # 首先找到所有分类的标题和描述
    category_pattern = r'【第(\d+)类】\s*([^<]+)</b></a>'
    category_matches = re.findall(category_pattern, html)
    
    for cat_id, cat_desc in category_matches:
        categories[int(cat_id)] = {
            'id': int(cat_id),
            'description': cat_desc.strip(),
            'subcategories': {}
        }
    
    # 匹配小类链接，格式如: href="1-0101.html" target="_blank">0101-工业气体，单质
    subcat_pattern = r'href="(\d+)-(\d{4})\.html"[^>]*>(\d{4})-([^<]+)</a>'
    subcat_matches = re.findall(subcat_pattern, html)
    
    for cat_id, subcode, _, subname in subcat_matches:
        cat_id = int(cat_id)
        if cat_id in categories:
            categories[cat_id]['subcategories'][subcode] = {
                'code': subcode,
                'name': subname.strip(),
                'url': f"{cat_id}-{subcode}.html"
            }
    
    return categories

def get_subcategory_page(cat_id, subcode):
    """获取小类详情页面"""
    url = f"{BASE_URL}/{cat_id}-{subcode}.html"
    try:
        resp = requests.get(url, headers=HEADERS, timeout=30)
        resp.encoding = 'utf-8'
        return resp.text
    except Exception as e:
        print(f"Error fetching {url}: {e}")
        return None

def parse_subcategory_page(html):
    """解析小类页面，提取商品列表"""
    items = []
    
    # 查找包含商品的div，class="sbflnr"
    content_pattern = r'<div class="sbflnr"[^>]*>(.*?)</div>'
    matches = re.findall(content_pattern, html, re.DOTALL)
    
    if matches:
        content = matches[0]
        
        # 商品格式：商品名010001； 或 商品名010001，
        # 支持中文分号和英文分号
        item_pattern = r'([^；;，,]+?)(\d{6})[；;，,]?'
        item_matches = re.findall(item_pattern, content)
        
        for name, code in item_matches:
            name = name.strip()
            if name and code:
                items.append({
                    'code': code,
                    'name': name
                })
    
    return items

def main():
    print("=" * 50)
    print("商标分类数据抓取脚本")
    print("=" * 50)
    
    # 输出目录
    output_dir = os.environ.get('COZE_WORKSPACE_PATH', '/workspace/projects') + '/src/data'
    os.makedirs(output_dir, exist_ok=True)
    
    # 获取首页
    print("\n1. 获取首页内容...")
    html = get_main_page()
    
    # 解析分类结构
    print("2. 解析分类结构...")
    categories = parse_main_page(html)
    print(f"   找到 {len(categories)} 个分类")
    
    # 统计小类数量
    total_subcats = sum(len(c['subcategories']) for c in categories.values())
    print(f"   找到 {total_subcats} 个小类")
    
    # 抓取每个小类的详细商品
    print("\n3. 抓取详细商品数据...")
    all_data = {}
    
    for cat_id in sorted(categories.keys()):
        cat = categories[cat_id]
        all_data[cat_id] = {
            'id': cat_id,
            'description': cat['description'],
            'subcategories': []
        }
        
        print(f"\n   第{cat_id}类 ({len(cat['subcategories'])} 个小类):")
        
        for subcode in sorted(cat['subcategories'].keys()):
            subcat = cat['subcategories'][subcode]
            
            # 获取详细页面
            page_html = get_subcategory_page(cat_id, subcode)
            
            if page_html:
                items = parse_subcategory_page(page_html)
                print(f"      {subcode} {subcat['name']}: {len(items)} 个商品")
                
                all_data[cat_id]['subcategories'].append({
                    'code': subcode,
                    'title': subcat['name'],
                    'items': items
                })
            else:
                print(f"      {subcode} {subcat['name']}: 获取失败")
                all_data[cat_id]['subcategories'].append({
                    'code': subcode,
                    'title': subcat['name'],
                    'items': []
                })
            
            # 避免请求过快
            time.sleep(0.3)
    
    # 保存数据
    print("\n4. 保存数据...")
    output_file = os.path.join(output_dir, 'trademark-detail-data.json')
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(all_data, f, ensure_ascii=False, indent=2)
    print(f"   数据已保存到: {output_file}")
    
    # 统计
    print("\n" + "=" * 50)
    print("统计信息:")
    total_items = sum(
        len(item['items']) 
        for cat in all_data.values() 
        for item in cat['subcategories']
    )
    print(f"   总分类数: {len(all_data)}")
    print(f"   总小类数: {sum(len(c['subcategories']) for c in all_data.values())}")
    print(f"   总商品数: {total_items}")
    print("=" * 50)

if __name__ == '__main__':
    main()
